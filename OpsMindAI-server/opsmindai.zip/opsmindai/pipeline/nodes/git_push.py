"""
opsmindai/pipeline/nodes/git_push.py

Commits generated test files to a new branch and opens a draft GitHub PR.

Called by the LangGraph pipeline after the testing/generation phase.
The local clone created by run_generation is still on disk (at repo_root)
and is used directly — no re-clone needed.

After this node, the pipeline continues to the testing/suite phase, which
runs pytest inside the same local clone.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import textwrap
from datetime import datetime, timezone
from typing import Optional

import httpx

from opsmindai.core.config import settings
from opsmindai.pipeline.state import PipelineState

logger = logging.getLogger(__name__)


# ── Git helpers ───────────────────────────────────────────────────────────────

def _git(args: list[str], cwd: str) -> str:
    """Run a git command, raise RuntimeError with stderr on failure."""
    result = subprocess.run(
        ["git", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"git {' '.join(args)} failed:\n{result.stderr.strip()}"
        )
    return result.stdout.strip()


# ── GitHub PR creation ────────────────────────────────────────────────────────

def _owner_repo(repo_url: str) -> tuple[str, str]:
    parts = repo_url.rstrip("/").split("/")
    return parts[-2], parts[-1].replace(".git", "")


def _pr_body(job_id: str, file_count: int, output_files: list[str]) -> str:
    file_list = "\n".join(f"- `{f}`" for f in output_files[:20])
    if len(output_files) > 20:
        file_list += f"\n- … and {len(output_files) - 20} more"
    return textwrap.dedent(f"""
        ## OpsMind AI — Auto-generated Test Stubs

        **Job ID:** `{job_id}`
        **Generated:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}
        **Files:** {file_count}

        ### Generated test files
        {file_list}

        ### Review checklist
        - [ ] Verify generated assertions reflect correct behaviour
        - [ ] Add edge cases and negative tests
        - [ ] Run the suite locally before merging

        ---
        *Opened automatically by [OpsMind AI](https://opsmindai.internal).*
    """).strip()


async def _create_pr(
    repo_url:    str,
    token:       str,
    head_branch: str,
    base_branch: str,
    job_id:      str,
    file_count:  int,
    output_files: list[str],
) -> tuple[str, Optional[int]]:
    """Open a GitHub draft PR. Returns (pr_url, pr_number)."""
    owner, repo = _owner_repo(repo_url)
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls"

    payload = {
        "title": f"feat(tests): auto-generated test stubs [{job_id[:8]}]",
        "head":  head_branch,
        "base":  base_branch,
        "body":  _pr_body(job_id, file_count, output_files),
        "draft": True,
    }
    headers = {
        "Authorization":        f"Bearer {token}",
        "Accept":               "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(url, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
        pr_url    = data.get("html_url", "")
        pr_number = data.get("number")
        logger.info("git_push: PR opened %s (#%s)", pr_url, pr_number)
        return pr_url, pr_number
    except Exception as exc:
        logger.warning("git_push: PR creation failed (non-fatal): %s", exc)
        return "", None


# ── Main node ─────────────────────────────────────────────────────────────────

async def git_push(state: PipelineState) -> dict:
    """
    LangGraph node: commit generated test files and open a GitHub draft PR.

    Reads repo_root and generated_files from PipelineState (populated by the
    testing/generation assembly step).  The local clone is left intact so the
    subsequent testing/suite phase can run pytest against it.

    Returns partial-state updates: pr_url, pr_number, status.
    """
    repo_url        = state.get("repo_url", "")
    branch          = state.get("branch", "main")
    repo_root       = state.get("repo_root", "")
    generated_files = state.get("generated_files", [])
    job_id          = state["job_id"]

    logger.info("git_push: job=%s files=%d", job_id, len(generated_files))

    # Guard: need a live local clone
    if not repo_root or not os.path.isdir(repo_root):
        logger.error("git_push: repo_root=%r not found", repo_root)
        return {"status": "failed", "error": "repo_root is missing for git_push"}

    output_files: list[str] = [
        f["output_file"] for f in generated_files if f.get("output_file")
    ]
    if not output_files:
        logger.warning("git_push: no output_files to commit — skipping push")
        return {"status": "completed"}  # non-fatal: suite can still run locally

    token = settings.GITHUB_TOKEN or os.environ.get("GITHUB_TOKEN", "")
    if not token:
        logger.warning("git_push: GITHUB_TOKEN not set — skipping push")
        return {"status": "completed"}

    timestamp   = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    test_branch = f"{settings.REFACTOR_BRANCH_PREFIX}/tests/{branch}-{timestamp}"

    try:
        # Configure git identity inside the clone
        _git(["config", "user.email", "opsmind-bot@opsmindai.internal"], cwd=repo_root)
        _git(["config", "user.name",  "OpsMind AI Bot"],                  cwd=repo_root)

        # Inject token into remote URL
        auth_url = repo_url.replace("https://", f"https://{token}@")
        _git(["remote", "set-url", "origin", auth_url], cwd=repo_root)

        # Create new branch from current HEAD
        _git(["checkout", "-b", test_branch], cwd=repo_root)

        # Stage only the generated test files that exist on disk
        staged: list[str] = []
        for rel_path in output_files:
            abs_path = os.path.join(repo_root, rel_path)
            if os.path.isfile(abs_path):
                _git(["add", rel_path], cwd=repo_root)
                staged.append(rel_path)
            else:
                logger.warning("git_push: output_file not found on disk: %s", abs_path)

        if not staged:
            logger.warning("git_push: no staged files — skipping commit")
            return {"status": "completed"}

        commit_msg = (
            f"feat(tests): auto-generated test stubs [{job_id[:8]}]\n\n"
            f"Generated by OpsMind Testing Agent for {len(staged)} file(s).\n"
            f"Job: {job_id}"
        )
        _git(["commit", "-m", commit_msg], cwd=repo_root)

        _git(["push", "origin", test_branch], cwd=repo_root)
        logger.info("git_push: pushed branch=%s", test_branch)

        pr_url, pr_number = await _create_pr(
            repo_url=repo_url,
            token=token,
            head_branch=test_branch,
            base_branch=branch,
            job_id=job_id,
            file_count=len(staged),
            output_files=staged,
        )

        return {
            "pr_url":    pr_url or None,
            "pr_number": pr_number,
            "status":    "completed",
        }

    except RuntimeError as exc:
        logger.exception("git_push: git command failed: %s", exc)
        return {"status": "failed", "error": str(exc)}
    except Exception as exc:
        logger.exception("git_push: unexpected error: %s", exc)
        return {"status": "failed", "error": str(exc)}

"""
opsmindai/pipeline/nodes/assembly.py

Dispatches to the correct agent phase function and advances the pipeline state.

Flow per call:
  1. Read state["phase"] and state["intent"]
  2. Build the agent payload from pipeline state
  3. Call the agent's async phase function (run_analysis, run_rca, etc.)
  4. Extract phase-specific results from Redis job state back into pipeline state
  5. Advance state["phase"] to the next phase (or "done")

A single async Redis client is created per invocation and closed in finally.
"""

from __future__ import annotations

import json
import logging
import uuid
from typing import Any, Optional

import redis.asyncio as aioredis

from opsmindai.core.config import settings
from opsmindai.pipeline.state import PHASE_SEQUENCE, PipelineState

logger = logging.getLogger(__name__)


# ── Redis helpers ─────────────────────────────────────────────────────────────

def _make_redis() -> aioredis.Redis:
    return aioredis.Redis.from_url(settings.REDIS_URL, decode_responses=True)


async def _read_job(redis: aioredis.Redis, key: str) -> dict:
    raw = await redis.get(key)
    return json.loads(raw) if raw else {}


async def _get_field(
    redis: aioredis.Redis,
    key: str,
    field: str,
    default: Any = None,
) -> Any:
    state = await _read_job(redis, key)
    return state.get(field, default)


# ── Per-intent payload builders ───────────────────────────────────────────────

def _refactor_payload(state: PipelineState, phase: str) -> dict:
    base = {
        "repo_url": state.get("repo_url", ""),
        "branch":   state.get("branch", "main"),
        "user_id":  state["user_id"],
    }
    if phase == "analyze":
        return {
            **base,
            "file_paths":         state.get("file_paths", []),
            "severity_threshold": state.get("severity_threshold", "medium"),
        }
    if phase == "suggest":
        return {**base, "smells": state.get("smells", [])}
    if phase == "apply":
        return {
            **base,
            "patches":       state.get("patches", []),
            "smells":        state.get("smells", []),
            "source_job_id": state["job_id"],
            "pr_title":      state.get("pr_title"),
            "pr_body":       state.get("pr_body"),
            "draft":         state.get("draft", True),
            "notify_slack":  True,
        }
    return base


def _sre_payload(state: PipelineState, phase: str) -> dict:
    base = {"user_id": state["user_id"]}
    if phase == "ingest":
        return {**base, "alert_payload": state.get("alert_payload", {})}
    if phase == "rca":
        return {**base, "incident_id": state.get("incident_id", "")}
    if phase == "remediate":
        return {
            **base,
            "incident_id": state.get("incident_id", ""),
            "playbook":    state.get("playbook", "auto"),
        }
    return base


def _testing_payload(state: PipelineState, phase: str) -> dict:
    base = {
        "repo_url": state.get("repo_url", ""),
        "branch":   state.get("branch", "main"),
        "user_id":  state["user_id"],
    }
    if phase == "generation":
        return {
            **base,
            "framework":          state.get("framework", "pytest"),
            "coverage_threshold": state.get("coverage_threshold", 0.80),
            "file_path":          state.get("file_path"),
            "pr_number":          state.get("pr_number"),
        }
    if phase == "suite":
        return {
            **base,
            "pr_number": state.get("pr_number"),
        }
    return base


# ── Main node ─────────────────────────────────────────────────────────────────

async def assembly(state: PipelineState) -> dict:
    """
    LangGraph node: execute the current agent phase and advance the pipeline.

    Returns a partial-state dict that LangGraph merges into PipelineState.
    """
    intent = state["intent"]
    phase  = state["phase"]
    job_id = state["job_id"]

    logger.info("assembly: intent=%s phase=%s job=%s", intent, phase, job_id)

    redis = _make_redis() # make a redis connection
    result_updates: dict = {}

    try:
        # ── Refactor ──────────────────────────────────────────────────────────
        if intent == "refactor":
            from opsmindai.agents.refactor.agent import (
                run_analysis, run_suggest, run_apply,
            )
            payload = _refactor_payload(state, phase)
            key = f"refactor:job:{job_id}"

            if phase == "analyze":
                await run_analysis(job_id, payload, redis)
                result_updates["smells"] = await _get_field(redis, key, "smells", [])

            elif phase == "suggest":
                await run_suggest(job_id, payload, redis)
                result_updates["patches"] = await _get_field(redis, key, "patches", [])

            elif phase == "apply":
                await run_apply(job_id, payload, redis)
                result_updates["pr_url"] = await _get_field(redis, key, "pr_url")

        # ── SRE ───────────────────────────────────────────────────────────────
        elif intent == "sre":
            from opsmindai.agents.sre_gpt.agent import (
                run_ingest, run_rca, run_remediate,
            )
            payload = _sre_payload(state, phase)

            if phase == "ingest":
                await run_ingest(job_id, payload, redis)
                key = f"sre_job:{job_id}"
                result_updates["incident_id"] = await _get_field(
                    redis, key, "incident_id"
                )

            elif phase == "rca": 
                incident_id = state.get("incident_id")
                if not incident_id:
                    raise ValueError("incident_id is required for the rca phase")
                rca_job_id = f"rca_{incident_id}"
                await run_rca(rca_job_id, payload, redis)
                key = f"sre_job:{rca_job_id}"
                result_updates["confidence"] = await _get_field(
                    redis, key, "confidence"
                )

            elif phase == "remediate":
                incident_id = state.get("incident_id")
                if not incident_id:
                    raise ValueError("incident_id is required for the remediate phase")
                rem_job_id = f"rem_{incident_id}"
                await run_remediate(rem_job_id, payload, redis)

        # ── Testing ───────────────────────────────────────────────────────────
        elif intent == "testing":
            from opsmindai.agents.testing.agent import run_generation, run_suite

            payload = _testing_payload(state, phase)
            key = f"testing:job:{job_id}"

            if phase == "generation":
                await run_generation(job_id, payload, redis)
                result_updates["repo_root"]       = await _get_field(redis, key, "repo_root")
                result_updates["generated_files"] = await _get_field(
                    redis, key, "generated_files", []
                )

            elif phase == "suite":
                # run_suite reads repo_root + framework from Redis (written by run_generation)
                await run_suite(job_id, payload, redis)
                result_updates["coverage"] = await _get_field(redis, key, "coverage")

        else:
            raise ValueError(f"Unknown intent: {intent!r}")

        # Advance phase
        next_phase = PHASE_SEQUENCE.get(intent, {}).get(phase)
        result_updates.update({
            "phase":           next_phase or "done",
            "completed_phase": phase,
            "status":          "completed",
        })
        logger.info(
            "assembly: done phase=%s next=%s job=%s",
            phase, next_phase or "done", job_id,
        )
        return result_updates

    except Exception as exc:
        logger.exception("assembly: phase=%s failed job=%s", phase, job_id)
        return {
            "phase":           "done",
            "completed_phase": phase,
            "status":          "failed",
            "error":           str(exc),
        }

    finally:
        await redis.aclose()

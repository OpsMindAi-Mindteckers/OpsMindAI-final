"""
opsmindai/pipeline/nodes/prompt_intake.py

Parses the user's natural-language prompt into a structured intent + parameters
using Claude claude-sonnet-4-6 with forced tool-call output.

Returns a partial-state dict merged into PipelineState by LangGraph.
"""

from __future__ import annotations

import logging
import uuid

import anthropic

from opsmindai.pipeline.state import FIRST_PHASE, PipelineState

logger = logging.getLogger(__name__)

_client = anthropic.AsyncAnthropic()

# ── Tool schema for structured extraction ─────────────────────────────────────

_PARSE_TOOL: dict = {
    "name": "parse_pipeline_intent",
    "description": (
        "Extract structured parameters from the user's DevOps request "
        "so the correct AI agent pipeline can be invoked."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "intent": {
                "type": "string",
                "enum": ["refactor", "sre", "testing"],
                "description": (
                    "Which agent to invoke: "
                    "'refactor' for code quality / smell fixes, "
                    "'sre' for incident response / RCA / remediation, "
                    "'testing' for test generation and coverage."
                ),
            },
            "repo_url": {
                "type": "string",
                "description": "HTTPS GitHub repository URL (e.g. https://github.com/org/repo)",
            },
            "branch": {
                "type": "string",
                "description": "Target git branch (default: main)",
            },
            # ── Refactor ──────────────────────────────────────────────────────
            "file_paths": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Specific file paths to analyse (refactor only). "
                    "Omit or leave empty to scan the whole repo."
                ),
            },
            "severity_threshold": {
                "type": "string",
                "enum": ["low", "medium", "high", "critical"],
                "description": "Minimum smell severity to report (refactor only, default: medium)",
            },
            "pr_title": {
                "type": "string",
                "description": "Custom GitHub PR title (refactor only)",
            },
            "draft": {
                "type": "boolean",
                "description": "Open PR as draft (refactor only, default: true)",
            },
            # ── SRE ───────────────────────────────────────────────────────────
            "alert_payload": {
                "type": "object",
                "description": (
                    "Alert payload dict for SRE ingest. "
                    "Required fields: alert_name, service, severity, source."
                ),
            },
            "playbook": {
                "type": "string",
                "enum": ["auto", "rollback", "restart", "scale", "flush_pool", "isolate_node", "manual"],
                "description": "Remediation playbook to execute (sre only, default: auto)",
            },
            # ── Testing ───────────────────────────────────────────────────────
            "framework": {
                "type": "string",
                "enum": ["pytest", "jest"],
                "description": "Test framework (testing only, default: pytest)",
            },
            "coverage_threshold": {
                "type": "number",
                "minimum": 0.0,
                "maximum": 1.0,
                "description": "Coverage gate threshold 0–1 (testing only, default: 0.80)",
            },
            "file_path": {
                "type": "string",
                "description": (
                    "Single relative file path to generate tests for (testing only). "
                    "Omit to generate tests for all files in the repo."
                ),
            },
        },
        "required": ["intent"],
    },
}

_SYSTEM = (
    "You are an AI pipeline router for the OpsMind DevOps platform. "
    "Parse the user's request and call parse_pipeline_intent with the correct parameters. "
    "You MUST call the tool — do not reply in plain text."
)


async def prompt_intake(state: PipelineState) -> dict:
    """
    LangGraph node: parse user prompt → structured intent + parameters.

    Uses Claude claude-sonnet-4-6 with a forced tool call so output is always
    structured.  Returns a partial-state dict that LangGraph merges into
    PipelineState.
    """
    prompt = state["prompt"]
    job_id = str(uuid.uuid4())

    logger.info("prompt_intake: parsing prompt job=%s", job_id)

    try:
        response = await _client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=1024,
            system=_SYSTEM,
            tools=[_PARSE_TOOL],
            tool_choice={"type": "tool", "name": "parse_pipeline_intent"},
            messages=[{"role": "user", "content": prompt}],
        )

        tool_block = next(
            (b for b in response.content if b.type == "tool_use"),
            None,
        )
        if not tool_block:
            raise ValueError("LLM did not return a tool_use block")

        parsed: dict = tool_block.input
        intent = parsed["intent"]
        first_phase = FIRST_PHASE[intent]

        updates: dict = {
            "job_id":   job_id,
            "intent":   intent,
            "phase":    first_phase,
            "status":   "pending",
            "repo_url": parsed.get("repo_url", ""),
            "branch":   parsed.get("branch", "main"),
        }

        if intent == "refactor":
            updates.update({
                "file_paths":         parsed.get("file_paths", []),
                "severity_threshold": parsed.get("severity_threshold", "medium"),
                "pr_title":           parsed.get("pr_title"),
                "draft":              parsed.get("draft", True),
            })

        elif intent == "sre":
            updates.update({
                "alert_payload": parsed.get("alert_payload", {}),
                "playbook":      parsed.get("playbook", "auto"),
            })

        elif intent == "testing":
            updates.update({
                "framework":          parsed.get("framework", "pytest"),
                "coverage_threshold": parsed.get("coverage_threshold", 0.80),
                "file_path":          parsed.get("file_path"),
            })

        logger.info(
            "prompt_intake: intent=%s phase=%s job=%s",
            intent, first_phase, job_id,
        )
        return updates

    except Exception as exc:
        logger.exception("prompt_intake failed: %s", exc)
        return {
            "job_id": job_id,
            "intent": "unknown",
            "phase":  "done",
            "status": "failed",
            "error":  f"Intent parsing failed: {exc}",
        }

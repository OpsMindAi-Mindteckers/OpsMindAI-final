"""
opsmindai/pipeline/graph.py

LangGraph StateGraph definition for the OpsMind AI orchestration pipeline.

Graph topology
──────────────

  START
    │
    ▼
  prompt_intake          (Claude claude-sonnet-4-6 → intent + params)
    │
    ▼ route_after_intake
  assembly ◄─────────────────────────────────────────────────┐
    │                                                         │
    ▼ route_after_assembly                                    │
    ├─ "assembly"  ───────────────────────────────────────────┘  next phase
    ├─ "git_push"  ──► git_push ──► route_after_git_push ────┘  testing only
    └─ END                                                        done / failed

Refactor:   prompt_intake → assembly(analyze) → assembly(suggest) → assembly(apply) → END
SRE-GPT:    prompt_intake → assembly(ingest)  → assembly(rca)     → assembly(remediate) → END
Testing:    prompt_intake → assembly(generation) → git_push → assembly(suite) → END

Usage
─────
    from opsmindai.pipeline.graph import pipeline

    result = await pipeline.ainvoke({
        "prompt":  "Refactor https://github.com/org/repo on branch dev",
        "user_id": "user_abc123",
    })
"""

from __future__ import annotations

from langgraph.graph import END, START, StateGraph

from opsmindai.pipeline.conditions import (
    route_after_assembly,
    route_after_git_push,
    route_after_intake,
)
from opsmindai.pipeline.nodes.assembly import assembly
from opsmindai.pipeline.nodes.git_push import git_push
from opsmindai.pipeline.nodes.prompt_intake import prompt_intake
from opsmindai.pipeline.state import PipelineState


def build_graph() -> StateGraph:
    """Construct and return the uncompiled StateGraph."""
    graph = StateGraph(PipelineState)

    # ── Nodes ─────────────────────────────────────────────────────────────────
    graph.add_node("prompt_intake", prompt_intake)
    graph.add_node("assembly",      assembly)
    graph.add_node("git_push",      git_push)

    # ── Entry edge ────────────────────────────────────────────────────────────
    graph.add_edge(START, "prompt_intake")

    # ── Conditional edges ─────────────────────────────────────────────────────
    graph.add_conditional_edges(
        "prompt_intake",
        route_after_intake,
        {"assembly": "assembly", END: END},
    )

    graph.add_conditional_edges(
        "assembly",
        route_after_assembly,
        {"assembly": "assembly", "git_push": "git_push", END: END},
    )

    graph.add_conditional_edges(
        "git_push",
        route_after_git_push,
        {"assembly": "assembly", END: END},
    )

    return graph


# Compiled pipeline — thread-safe singleton, import and call ainvoke() directly.
pipeline = build_graph().compile()

"""
opsmindai/pipeline/conditions.py

Conditional-edge routing functions for the LangGraph pipeline.

Each function receives the full PipelineState and returns the name of the
next node (string) or END.  They must not modify state.
"""

from __future__ import annotations

from langgraph.graph import END

from opsmindai.pipeline.state import NEEDS_GIT_PUSH, PHASE_SEQUENCE, PipelineState


def route_after_intake(state: PipelineState) -> str:
    """Always go to assembly after prompt_intake, unless intake itself failed."""
    if state.get("status") == "failed":
        return END
    return "assembly"


def route_after_assembly(state: PipelineState) -> str:
    """
    After an assembly phase completes:
    - failure        → END
    - needs git_push → "git_push"  (e.g. testing/generation pushes test files)
    - more phases    → "assembly"  (keep running next phase)
    - pipeline done  → END
    """
    if state.get("status") == "failed":
        return END

    intent    = state.get("intent", "")
    completed = state.get("completed_phase", "")

    if (intent, completed) in NEEDS_GIT_PUSH:
        return "git_push"

    if state.get("phase") == "done":
        return END

    return "assembly"


def route_after_git_push(state: PipelineState) -> str:
    """After git_push, continue to assembly for the next phase or END on failure."""
    if state.get("status") == "failed":
        return END
    return "assembly"

"""
opsmindai/pipeline/state.py

Shared state TypedDict that flows through the LangGraph pipeline.

Fields are populated progressively as each node runs:
  prompt_intake → sets intent, repo_url, phase, job_id, …
  assembly      → sets smells/patches/incident_id/generated_files/…
  git_push      → sets pr_url, pr_number (testing branch)
"""

from __future__ import annotations

from typing import Any, Optional
from typing_extensions import NotRequired, TypedDict


class PipelineState(TypedDict):
    # ── Input (always required) ───────────────────────────────────────────────
    prompt:  str
    user_id: str

    # ── Parsed intent (set by prompt_intake) ──────────────────────────────────
    intent:   str          # "refactor" | "sre" | "testing"
    repo_url: NotRequired[str]
    branch:   NotRequired[str]

    # ── Job lifecycle (set by prompt_intake, updated by assembly) ─────────────
    job_id:          str
    phase:           str   # currently executing phase name, or "done"
    completed_phase: NotRequired[str]   # phase that just finished (read by conditions)
    status:          str   # pending | running | completed | failed
    error:           NotRequired[str]

    # ── Refactor-specific fields ──────────────────────────────────────────────
    file_paths:         NotRequired[list[str]]
    severity_threshold: NotRequired[str]
    smells:             NotRequired[list[dict]]   # list[SmellItem.model_dump()]
    patches:            NotRequired[list[dict]]   # list[PatchFile.model_dump()]
    pr_title:           NotRequired[Optional[str]]
    pr_body:            NotRequired[Optional[str]]
    draft:              NotRequired[bool]

    # ── SRE-specific fields ───────────────────────────────────────────────────
    alert_payload: NotRequired[dict]
    incident_id:   NotRequired[str]
    confidence:    NotRequired[float]
    playbook:      NotRequired[str]

    # ── Testing-specific fields ───────────────────────────────────────────────
    framework:          NotRequired[str]
    coverage_threshold: NotRequired[float]
    file_path:          NotRequired[Optional[str]]   # single target file (or None = whole repo)
    generated_files:    NotRequired[list[dict]]       # list[{source_file, output_file, …}]
    repo_root:          NotRequired[str]              # local clone path (generation → git_push → suite)
    pr_number:          NotRequired[Optional[int]]

    # ── Output ────────────────────────────────────────────────────────────────
    pr_url:   NotRequired[Optional[str]]
    coverage: NotRequired[dict]
    result:   NotRequired[dict[str, Any]]


# Phase ordering for each intent — used by assembly (advance) and conditions (route).
PHASE_SEQUENCE: dict[str, dict[str, str | None]] = {
    "refactor": {"analyze": "suggest", "suggest": "apply",     "apply":      None},
    "sre":      {"ingest":  "rca",     "rca":     "remediate", "remediate":  None},
    "testing":  {"generation": "suite", "suite":  None},
}

FIRST_PHASE: dict[str, str] = {
    "refactor": "analyze",
    "sre":      "ingest",
    "testing":  "generation",
}

# (intent, completed_phase) pairs that require a git_push node before continuing.
NEEDS_GIT_PUSH: frozenset[tuple[str, str]] = frozenset({
    ("testing", "generation"),
})

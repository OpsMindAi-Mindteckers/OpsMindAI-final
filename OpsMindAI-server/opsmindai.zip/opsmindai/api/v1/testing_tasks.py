"""
opsmindai/api/v1/testing_tasks.py

Celery task definitions for the three-phase Testing Agent pipeline.

Workers:
    celery -A opsmindai.core.celery_app worker --loglevel=info -Q testing

Each task bridges the sync Celery context to the async agent.py coroutines
via _run_async() and an _AsyncRedisAdapter.
"""

from __future__ import annotations

import asyncio
import logging
import os

import redis as sync_redis

from opsmindai.core.celery_app import celery_app

logger = logging.getLogger(__name__)


def _sync_redis() -> sync_redis.Redis:
    return sync_redis.Redis.from_url(
        os.environ.get("REDIS_URL", "redis://localhost:6379/0"),
        decode_responses=True,
    )


class _AsyncRedisAdapter:
    """
    Minimal async wrapper around the sync redis.Redis client.
    Mirrors the methods used by agents/testing/agent.py.
    """
    def __init__(self, client: sync_redis.Redis):
        self._r = client

    async def get(self, key: str):
        return self._r.get(key)

    async def set(self, key: str, value: str):
        return self._r.set(key, value)

    async def setex(self, key: str, ttl: int, value: str):
        return self._r.setex(key, ttl, value)

    async def lpush(self, key: str, *values):
        return self._r.lpush(key, *values)

    async def lrange(self, key: str, start: int, stop: int):
        return self._r.lrange(key, start, stop)

    async def expire(self, key: str, ttl: int):
        return self._r.expire(key, ttl)

    async def delete(self, *keys):
        return self._r.delete(*keys)


def _run_async(coro):
    """
    Run an async coroutine from a sync Celery worker, then drain all pending
    tasks and async generators before closing the loop.

    Replaces bare _run_async() to prevent 'Event loop is closed' errors from
    httpx/anyio connection-pool cleanup that fires after the loop tears down.
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        try:
            pending = asyncio.all_tasks(loop)
            if pending:
                loop.run_until_complete(
                    asyncio.gather(*pending, return_exceptions=True)
                )
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
        finally:
            asyncio.set_event_loop(None)
            loop.close()


# ── Phase 1: Generate ─────────────────────────────────────────────────────────

@celery_app.task(
    name="testing.run_generation",
    bind=True,
    max_retries=2,
    default_retry_delay=10,
    queue="testing",
    acks_late=True,
    reject_on_worker_lost=True,
    soft_time_limit=240,   # LLM generation can be slow for large repos
    time_limit=240,
)
def task_run_generation(self, job_id: str, payload: dict) -> None:
    """Phase 1 — Clone repo, generate LLM test stubs."""
    from opsmindai.agents.testing.agent import run_generation

    logger.info("[testing.run_generation] job=%s repo=%s starting",
                job_id, payload.get("repo_url"))
    r = _sync_redis()
    redis = _AsyncRedisAdapter(r)
    try:
        _run_async(run_generation(job_id, payload, redis))
        logger.info("[testing.run_generation] job=%s done", job_id)
    except Exception as exc:
        logger.exception("[testing.run_generation] job=%s failed", job_id)
        try:
            self.retry(exc=exc)
        except self.MaxRetriesExceededError:
            raise
    finally:
        r.close()


# ── Phase 2: Suite ────────────────────────────────────────────────────────────

@celery_app.task(
    name="testing.run_suite",
    bind=True,
    max_retries=2,
    default_retry_delay=15,
    queue="testing",
    acks_late=True,
    reject_on_worker_lost=True,
    soft_time_limit=300,   # test execution + coverage parse
    time_limit=360,
)
def task_run_suite(self, job_id: str, payload: dict) -> None:
    """Phase 2 — Execute generated tests and enforce coverage gate."""
    from opsmindai.agents.testing.agent import run_suite

    logger.info("[testing.run_suite] job=%s source_job=%s starting",
                job_id, payload.get("job_id"))
    r = _sync_redis()
    redis = _AsyncRedisAdapter(r)
    try:
        _run_async(run_suite(job_id, payload, redis))
        logger.info("[testing.run_suite] job=%s done", job_id)
    except Exception as exc:
        logger.exception("[testing.run_suite] job=%s failed", job_id)
        try:
            self.retry(exc=exc)
        except self.MaxRetriesExceededError:
            raise
    finally:
        r.close()


# ── Phase 3: Regression ───────────────────────────────────────────────────────

@celery_app.task(
    name="testing.run_regression",
    bind=True,
    max_retries=2,
    default_retry_delay=20,
    queue="testing",
    acks_late=True,
    reject_on_worker_lost=True,
    soft_time_limit=480,
    time_limit=540,
)
def task_run_regression(self, job_id: str, payload: dict) -> None:
    """Phase 3 — Build incident-driven regression + load + DB perf test suite."""
    from opsmindai.agents.testing.agent import run_regression

    logger.info("[testing.run_regression] job=%s repo=%s starting",
                job_id, payload.get("repo_url"))
    r = _sync_redis()
    redis = _AsyncRedisAdapter(r)
    try:
        _run_async(run_regression(job_id, payload, redis))
        logger.info("[testing.run_regression] job=%s done", job_id)
    except Exception as exc:
        logger.exception("[testing.run_regression] job=%s failed", job_id)
        try:
            self.retry(exc=exc)
        except self.MaxRetriesExceededError:
            raise
    finally:
        r.close()
from setuptools import setup, find_packages

setup(
    name="opsmindai",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.10",
)
